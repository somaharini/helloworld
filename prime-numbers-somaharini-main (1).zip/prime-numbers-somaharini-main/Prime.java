public class Prime{
  // Start your code from here
  
}
